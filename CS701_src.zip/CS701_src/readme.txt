ไฟล์เอ็กเซล .xlsm เป็นข้อมูลจากการรวบรวมทวิตเตอร์ที่มีเนื้อหาเกี่ยววัคซีนในแต่ละสูตร ประกอบด้วย
Sinovac_Astra.xlsm
Sinopharm_Astra.xlsm
Sinovac_Pfizer.xlsm
Sinopharm_Pfizer.xlsm
Astra_Pfizer.xlsm

ซอร์สโค้ดภาษาไพทอน (.ipynb) เป็นการทำ sentiment analysis ของแต่ละชุดข้อมูล ประกอบด้วย
Sinovac_Astra.ipynb
Sinopharm_Astra.ipynb
Sinovac_Pfizer.ipynb
Sinopharm_Pfizer.ipynb
Astra_Pfizer.ipynb

ไฟล์ .txt เป็นผลลัพธ์จากการทำ sentiment analysis ของแต่ละชุดข้อมูล ประกอบด้วย
Sinovac_Astra.txt
Sinopharm_Astra.txt
Sinovac_Pfizer.txt
Sinopharm_Pfizer.txt
Astra_Pfizer.txt

ขั้นตอนการทำงาน
1. รับเข้าข้อมูลของชุดข้อมูลที่ต้องการ ดูตัวอย่างและจำนวนข้อมูล เนื่องจากการเก็บข้อมูลประกอบด้วย 2 คีย์เวิร์ด จึงแบ่งการเก็บออกเป็น 2 ชีท อ่านข้อมูลของทั้งสองชีทและรวมข้อมูลทั้งหมด ดูจำนวนรวม
2. นำข้อมูลมาทำ Bag-of-word เพื่อดูความนิยมของคำที่มักจะพบในข้อมูลนั้น ๆ
3. นำข้อมูลมาทำ Sentiment Analysis โดยใช้ AI for Thai:SSense API
4. บันทึกผลลัพธ์ที่ได้จากการนำ อัปโหลดลงไดร์ฟ
5. อ่านไฟล์ผลลัพธ์ เนื่องจาก AI for Thai เป็นการวิเคราะห์ว่าข้อความนั้นเป็นเชิงหรือบวกหรือลบ จึงอนุมานให้ข้อความที่เหลือเป็นเชิงกลาง ๆ
6. แสดงผลลัพธ์ของแต่ละความรู้สึกผ่าน Barplot